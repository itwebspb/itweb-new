Перенос на itweb-new.acrobat.test-itweb.ru
==========================================

1) Скопируйте содержимое папки bitrix/ в корень сайта (с заменой файлов).
   Важно: header.php — полная замена файла из этого архива
   (в нём добавлено подключение design-model.css).

2) В админке Bitrix создайте/обновите элемент инфоблока 21, раздел 158:
   - Название: Сайты на 1С-Битрикс
   - Символьный код: sayty-na-1c-bitriks
   - Детальный текст (HTML): вставьте содержимое файла
     bitrix/templates/aspro_max/design-model/pages/uslugi-sozdanie-saytov-1c-bitriks.html

3) Очистите кэш Bitrix (cache + managed_cache, особенно bitrix/cache/css/).

4) Проверка:
   https://itweb-new.acrobat.test-itweb.ru/services/sozdanie-saytov/sayty-na-1c-bitriks/
